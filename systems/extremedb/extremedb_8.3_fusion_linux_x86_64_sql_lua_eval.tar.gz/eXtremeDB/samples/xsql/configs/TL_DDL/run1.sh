#!/bin/bash

../../../../target/bin/xsql -c xsql.cfg -f init.sql -i

