disk

This configuration demonstrates a simple persistent database server.

To start server with interactive console, type:
  cd disk
  ../../../../target/bin/xsql -c xsql.cfg -i
  ...
  XSQL>select * from Employee;

