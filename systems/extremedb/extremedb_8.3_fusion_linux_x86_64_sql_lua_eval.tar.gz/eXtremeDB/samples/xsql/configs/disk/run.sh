#!/bin/bash

../../../../target/bin/xsql -c xsql.cfg -i
