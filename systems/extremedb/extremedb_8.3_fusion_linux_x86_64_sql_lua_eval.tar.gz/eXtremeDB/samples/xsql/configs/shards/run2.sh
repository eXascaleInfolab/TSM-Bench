#!/bin/bash

../../../../target/bin/xsql -c shard2.cfg -i

