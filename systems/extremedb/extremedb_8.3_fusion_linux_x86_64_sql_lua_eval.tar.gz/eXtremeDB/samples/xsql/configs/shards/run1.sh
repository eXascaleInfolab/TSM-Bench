#!/bin/bash

../../../../target/bin/xsql -c shard1.cfg -i

