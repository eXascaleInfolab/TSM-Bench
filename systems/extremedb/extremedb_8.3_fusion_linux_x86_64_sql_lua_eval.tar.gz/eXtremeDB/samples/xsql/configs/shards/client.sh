#!/bin/bash

../../../../target/bin/xsql -c client.cfg -i

