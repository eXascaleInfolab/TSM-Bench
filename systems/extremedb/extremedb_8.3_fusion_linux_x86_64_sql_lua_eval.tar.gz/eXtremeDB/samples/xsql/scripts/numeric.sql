create table "t 1" (x numeric(8,2));
insert into "t 1" (x) values ('3.14');
insert into "t 1" (x) values ('1.2'); 
insert into "t 1" (x) values (3.14);
insert into "t 1" (x) values (5);
insert into "t 1" (x) values (2.1);
select * from "t 1"; 
