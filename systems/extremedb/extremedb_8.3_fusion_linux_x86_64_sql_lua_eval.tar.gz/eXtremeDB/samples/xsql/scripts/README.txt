SQL sample files *.sql in this directory are designed to demonstrate eXtremeSQL engine capability.

With utility 'xsql' run following lines:
    ..\..\..\target\bin\xsql.exe -i -c xsql.cfg -f array.sql (or any other *.sql file) on Windows
    ../../../target/bin/xsql -i -c xsql.cfg -f array.sql (or any other *.sql file) on Unixes

