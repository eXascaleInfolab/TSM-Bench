#!/usr/bin/env bash

export MCO_ROOT=`(cd ../../../.. && pwd)`

export LD_LIBRARY_PATH=$MCO_ROOT/target/bin.so/:$LD_LIBRARY_PATH
if [ "$(uname)" == "Darwin" ]; then
    DYLD_LIBRARY_PATH=$MCO_ROOT/target/bin.so/:$DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH
fi

$MCO_ROOT/target/bin/xsql -c xsql.cfg -b -f $1.sql
