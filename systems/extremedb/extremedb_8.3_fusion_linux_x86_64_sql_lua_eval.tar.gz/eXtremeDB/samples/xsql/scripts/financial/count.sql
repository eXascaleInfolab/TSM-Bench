format CSV
select count(symbol) as "Quote records inserted" from Quote;