#!/usr/bin/env bash
../../../../target/bin/xsql $*
