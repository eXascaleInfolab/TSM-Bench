create table t (i integer, r real, s varchar);
insert into t values ([1,2,3,4,5], [1.0, 2.0, 3.0, 4.0, 5.0], ['one', 'two', 'three', 'four', 'five']);
select * from t;
