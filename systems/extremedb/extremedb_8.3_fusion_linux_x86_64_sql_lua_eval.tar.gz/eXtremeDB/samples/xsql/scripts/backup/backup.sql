-- Demonstrare backup command

CREATE TABLE Tab(i integer primary key, value string);

INSERT INTO Tab(i, value) VALUES (
    [1,2,3,4,5],
    ['string 1', 'string 2', 'string 3', 'string 4', 'string 5']
);

BACKUP 'my_backup.bak' FULL 'Initial full';

INSERT INTO Tab(i, value) VALUES (
    [6,7,8],
    ['string 6', 'string 7', 'string 8']
);

-- Add new data to the backup

BACKUP 'my_backup.bak' INCREMENTAL 'updated';

-- Backup should now contain all

SELECT * FROM BACKUP 'my_backup.bak';

-- Check the backup

VERIFY 'my_backup.bak' LABEL 'Initial full';

VERIFY 'my_backup.bak' LABEL 'updated';
