#!/usr/bin/env bash

../../../../target/bin/xsql -c xsql.cfg -f $1.sql -i
