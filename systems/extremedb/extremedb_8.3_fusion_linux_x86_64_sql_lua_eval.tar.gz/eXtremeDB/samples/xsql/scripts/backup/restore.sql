-- Demonstrare restore command

RESTORE 'my_backup.bak' TO 'Initial full';

SELECT * FROM Tab;

RESTORE 'my_backup.bak' TO 'updated';

SELECT * FROM Tab;
