create table t(pk integer primary key, i integer default 1, s string default 'ok', dt time default '10:00');
insert into t (pk) values (0);
select * from t;
