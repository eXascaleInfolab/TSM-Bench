create table foo(x integer);
insert into foo values (1),(2),(3);
select * from foo;
truncate foo;
select * from foo;
