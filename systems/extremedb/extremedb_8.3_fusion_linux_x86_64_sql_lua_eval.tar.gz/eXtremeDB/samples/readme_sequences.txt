samples/csharp/seqapi
samples/java/seqapi
samples/native/sequences/...
samples/native/sql/api/sql-11-sequences
samples/python/seqapi
samples/python/seqbasic
samples/xsql/scripts/sequences
