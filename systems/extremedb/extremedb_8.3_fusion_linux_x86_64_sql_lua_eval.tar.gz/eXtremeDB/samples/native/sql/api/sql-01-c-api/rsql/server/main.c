/****************************************************************
 *                                                              *
 * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *  * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *
 *                                                              *
 ****************************************************************/
#include "sqlc.h"
#include "mcoapic.h"
#include "sqlsrv_c.h"

#include "common.h"
#include "commonSQL.h"

#include "c_rsqldb.h"

static const char g_sample_descr[] = 
"Sample 'c_rsql_server' demonstrates the server-side implementation in a\n"
"C client-server application\n";

static const char *g_db_name = "c_rsqldb";
static const int g_server_port = 5001;


/* MCO error handler */
static void extremedb_error_handler(MCO_RET error_code)
{
  fprintf(stderr, "eXtremeDB error %d\n", error_code);
  sample_os_shutdown();
  dbg_exit(1);
}

static void run_server(database_t engine, mco_bool auth) {
  sqlsrv_t server = NULL;
  status_t rs = SQL_OK;

  if (auth) {
    rs = sqlsrv_create_ex(&server, (storage_t)engine, g_server_port, 64 * 1024, 8, 5, NULL, MCO_NO, 0, MCO_YES, 100, 0, MCO_NO);
  } else {
    rs = sqlsrv_create(&server, (storage_t)engine, g_server_port, 64 * 1024, 8, 5, NULL);
  }
  sample_sql_rc_check("\tCreate server", (MCO_RET)rs);

  if (rs == SQL_OK) {
    rs = sqlsrv_start(server);
    sample_sql_rc_check("\tStart server", (MCO_RET)rs);

    if (rs == SQL_OK) {
      sample_pause("\n\tServer started: press ENTER to terminate.\n\n");

      rs = sqlsrv_stop(server);
      sample_sql_rc_check("\tStop server", (MCO_RET)rs);
    }
  
    rs = sqlsrv_destroy(server);
    sample_sql_rc_check("\tDestroy server", (MCO_RET)rs);
  }
}

int main(int argc, char** argv)
{
  MCO_RET           rc;
  status_t          rs;
  mco_db_h          db;
  mco_device_t      dev;
  mco_db_params_t   db_params;
  database_t        engine;
  mco_bool          auth;

  auth = (argc > 1 && strcmp(argv[1], "-auth") == 0) ? MCO_YES : MCO_NO;

  sample_os_initialize(DEFAULT);

  sample_header(g_sample_descr);

  /* set fatal error handler */
  mco_error_set_handler(extremedb_error_handler);

  /* start eXtremeDB runtime */
  mco_runtime_start();

  /* setup memory device as a plain conventional memory region */
  dev.type       = MCO_MEMORY_CONV;                /* set the device as a conventional memory device */
  dev.assignment = MCO_MEMORY_ASSIGN_DATABASE;     /* assign the device as main database memory */
  dev.size       = DATABASE_SIZE;                  /* set the device size */
  dev.dev.conv.ptr = (void *)malloc(DATABASE_SIZE);
  if (!dev.dev.conv.ptr) {
    extremedb_error_handler(MCO_E_NOMEM);
  }

  /* initialize and customize the database parameters */
  mco_db_params_init (&db_params);                 /* initialize the params with default values */
  db_params.mem_page_size      = MEMORY_PAGE_SIZE; /* set page size for the in memory part */
  db_params.disk_page_size     = 0;                /* set page size to zero to disable disk operations */
  db_params.db_max_connections = 10;               /* set total number of connections to the database */
  db_params.db_log_type        = REDO_LOG;         /* set transaction log type */
#ifdef EXTREMEDB_LICENSE_KEY
  db_params.license_key        = EXTREMEDB_LICENSE_KEY;
#endif

  /* open a database on the device with given params */
  rc = mco_db_open_dev(g_db_name, c_rsqldb_get_dictionary(), &dev, 1, &db_params);
  if (MCO_S_OK == rc) {
    /* the database was opened successfully */
    sample_rc_check("\tOpen database", rc);

    /* connect to the database by name */
    rc = mco_db_connect(g_db_name, &db);

    if (MCO_S_OK == rc) {
      /* the database is open and a connection successfully established */
      sample_rc_check("\tConnect database", rc);

      rs = mcoapi_create_engine(db, &engine);
      sample_sql_rc_check("\tCreate SQL engine", (MCO_RET)rs);

      if (SQL_OK == rs) {
        rs = mcosql_execute_statement(engine, NULL, NULL,
          "INSERT INTO aRecord (id, value) VALUES ('#123', 'server-side value')");
        sample_sql_rc_check("\tInsert one record", (MCO_RET)rs);

        if (auth) {
            rs = mcosql_execute_statement(engine, NULL, NULL,
                "INSERT INTO Users (login, password) VALUES ('usr', 'pwd')");
            sample_sql_rc_check("\tInsert credentials of one user", (MCO_RET)rs);
        }
        sample_sql_rc_check("\tInsert one record", (MCO_RET)rs);

        run_server(engine, auth);

        rs = mcoapi_destroy_engine(engine);
        sample_sql_rc_check("\tDestroy SQL engine", (MCO_RET)rs);
      }
    }

    /* disconnect from the database */
    rc = mco_db_disconnect(db);
    sample_rc_check("\tDisconnect database", rc);

    /* close the database */
    rc = mco_db_close(g_db_name);
    sample_rc_check("\tClose database", rc);
  } else {
    /* unable to open the database */
    /* check the return code for additional informaton */
    sample_rc_check("\tOpen failed", rc);
  }

  /* stop eXtremeDB runtime */
  mco_runtime_stop();

  /* free allocated database memory */
  free(dev.dev.conv.ptr);

  sample_pause_end("\n\nPress any key to continue . . . ");

  sample_os_shutdown();
  return 0;
}
