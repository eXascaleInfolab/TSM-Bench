/****************************************************************
 *                                                              *
 * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *  * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *
 *                                                              *
 ****************************************************************/
#include "sqlc.h"
#include "mcoapic.h"
#include "sqlcln_c.h"

#include "common.h"
#include "commonSQL.h"

#include "c_rsqldb.h"

static const char g_sample_descr[] = 
"Sample 'c_rsql_client' demonstrates the client-side implementation in a\n"
"C client-server application\n";

static const int g_server_port = 5001;
static const char *g_server_host = "localhost";


/* MCO error handler */
static void extremedb_error_handler(MCO_RET error_code)
{
  fprintf(stderr, "eXtremeDB error %d\n", error_code);
  sample_os_shutdown();
  dbg_exit(1);
}

static void show_value(database_t engine, const char *head, const char *key)
{
  data_source_t result = NULL;
  status_t rs = SQL_OK;

  rs = mcosql_execute_query(engine, NULL, &result,
    "SELECT value FROM aRecord where id=%s", key);
  if (rs == SQL_OK) {
    cursor_t cur = NULL;

    rs = mcosql_get_cursor(result, &cur);
    if (rs == SQL_OK) {
      record_t rec = NULL;

      rs = mcosql_cursor_move_next(cur, &rec);
      if (rs == SQL_OK) {
        char buf[64];
        size_t val_size = 0;

        rs = mcosql_get_column_value_as(rec, 0, CT_STRING, buf, sizeof(buf), &val_size);
        if (rs == SQL_OK) {
          printf("\n\t%s key=%s: value='%s'\n", head, key, buf);
        } else {
          sample_sql_rc_check("\tGet column value", (MCO_RET)rs);
        }
      } else {
        sample_sql_rc_check("\tAdvance cursor", (MCO_RET)rs);
      }
    } else {
      sample_sql_rc_check("\tGet cursor", (MCO_RET)rs);
    }

    rs = mcosql_release_query_result(result);
    if (rs != SQL_OK) {
      sample_sql_rc_check("\tRelease query result", (MCO_RET)rs);
    }
  } else {
    sample_sql_rc_check("\tSELECT", (MCO_RET)rs);
  }
}

static void run_queries(database_t engine)
{
  const char *key = "#123";
  status_t rs = SQL_OK;

  show_value(engine, "Initial value for record with ", key);
  rs = mcosql_execute_statement(engine, NULL, NULL,
    "UPDATE aRecord set value='client-side value' where id=%s", key);
  sample_sql_rc_check("\tUpdate remote object", (MCO_RET)rs);
  if (SQL_OK == rs || NO_MORE_ELEMENTS == rs) {
    show_value(engine, "After update ", key);
  }
}

int main(int argc, char** argv)
{
  status_t          rs;
  database_t        engine;
  mco_bool          auth;

  auth = (argc > 1 && strcmp(argv[1], "-auth") == 0) ? MCO_YES : MCO_NO;

  sample_os_initialize(DEFAULT);

  sample_header(g_sample_descr);

  /* set fatal error handler */
  mco_error_set_handler(extremedb_error_handler);

  /* start eXtremeDB runtime */
  mco_runtime_start();

  rs = sqlcln_create(&engine, 64 * 1024);
  sample_sql_rc_check("\tCreate the RSQL client engine", (MCO_RET)rs);

  if (rs == SQL_OK) {
    rs = sqlcln_open(engine, g_server_host, g_server_port, 3);
    sample_sql_rc_check("\tConnect to the server", (MCO_RET)rs);

    if (auth) {
        rs = sqlcln_authenticate(engine, "usr", "pwd");
        sample_sql_rc_check("\tAuthenticate on the server", (MCO_RET)rs);
    }

    if (rs == SQL_OK) {
      run_queries(engine);

      rs = sqlcln_close(engine);
      sample_sql_rc_check("\tDisconnect from the server", (MCO_RET)rs);
    }

    rs = sqlcln_destroy(engine);
    sample_sql_rc_check("\tDestroy the RSQL client engine", (MCO_RET)rs);
  }

  /* stop eXtremeDB runtime */
  mco_runtime_stop();

  sample_pause_end("\n\nPress any key to continue . . . ");

  sample_os_shutdown();
  return 0;
}
