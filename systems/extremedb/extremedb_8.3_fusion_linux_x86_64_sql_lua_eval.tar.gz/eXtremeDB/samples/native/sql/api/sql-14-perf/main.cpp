/****************************************************************
 *                                                              *
 * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.   *  * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.   *
 *                                                              *
 ****************************************************************/
#include "mcosql.h"
#include "sqlcln.h"
#include "sqlsrv.h"
#include <string.h>
#include <time.h>
#include <locale.h>
#include <commonSQL.h>

#define MEMORY_DATABASE_SIZE 128*1024*1024
#define SERVER_PORT 5001
#define BULK_SIZE 1000

using namespace McoSql;

void run_test(SqlEngine *engine, bool remote)
{
    PreparedStatement stmt;
    uint4 nRecords = 100000;
    uint4 key;
    char  value[16];
    time_t duration, start_time;

    engine->prepare(stmt, "insert into Record (id, value) values(%*i, %*S)", &key, value);

    engine->executeStatement("delete from Record");

    printf("Insert objects separately (auto-commit)\n");
    start_time = sample_msec();
    for (key = 0; key < nRecords; key++)
    {
        sprintf(value, "__%010d__", key);
        engine->executePreparedStatement(stmt);
    }
    duration = sample_msec() - start_time;
    printf("%d objects inserted at %d milliseconds (%lld objects per second)\n", nRecords, (int)duration, 1000LL * nRecords / duration);

    engine->executeStatement("delete from Record");

    Transaction* trans;
    if (remote) {
        engine->executeStatement("start transaction");
    } else {
        trans = engine->beginTransaction(Transaction::ReadWrite);
    }
    printf("Insert objects by %d per transaction\n", BULK_SIZE);
    start_time = sample_msec();
    for (key = 0; key < nRecords; key++)
    {
        sprintf(value, "__%010d__", key);
        engine->executePreparedStatement(stmt);
        if (key % BULK_SIZE == 0) {
            if (remote) {
                engine->executeStatement("commit transaction");
                engine->executeStatement("start transaction");
            } else {
                trans->commit();
                trans->release();
                trans = engine->beginTransaction(Transaction::ReadWrite);
            }
        }
    }
    if (remote) {
        engine->executeStatement("commit transaction");
    } else {
        trans->commit();
        trans->release();
    }
    duration = sample_msec() - start_time;
    printf("%d objects inserted at %d milliseconds (%lld objects per second)\n", nRecords, (int)duration, 1000LL * nRecords / duration);

    engine->executeStatement("delete from Record");

    printf("Insert objects by array[%d] (auto-commit)\n", BULK_SIZE);

    Array* key_array = Array::create(engine->getAllocator(), tpInt4, 0, BULK_SIZE);
    Array* value_array = Array::create(engine->getAllocator(), tpString, 0, BULK_SIZE);

    start_time = sample_msec();
    int array_idx = 0;
    for (key = 0; key < nRecords; key++)
    {
        sprintf(value, "__%010d__", key);

        key_array->setAt(array_idx, IntValue::create(engine->getAllocator(), key));
        value_array->setAt(array_idx, String::create(engine->getAllocator(), value));
        array_idx++;

        if (array_idx == BULK_SIZE)
        {
            engine->executeStatement("insert into Record (id, value) values(%v, %v)", key_array, value_array);
            array_idx = 0;
        }
    }
    CHECK_VALUE(array_idx, 0);
    duration = sample_msec() - start_time;
    printf("%d objects inserted at %d milliseconds (%lld objects per second)\n", nRecords, (int)duration, 1000LL * nRecords / duration);

    DELETE_OBJ(engine->getAllocator(), key_array);
    DELETE_OBJ(engine->getAllocator(), value_array);
}

void query_objects(SqlEngine *engine, bool ascending = true)
{
    printf("Print %s 5 objects\n", ascending ? "first" : "last");

    char sql[128];
    sprintf(sql, "select id, value from Record order by id %s limit 5", ascending ? "asc" : "desc");

    int count = 0;
    QueryResult result(engine->executeQuery(sql));
    Cursor* cursor = result->records();
    while (cursor->hasNext())
    {
        McoSql::Allocator allocator;
        Record* rec = cursor->next();
        printf("id:%d, value:%s\n", (int)rec->getInt(0), rec->get(1)->stdStringValue(&allocator).c_str());
        count++;
    }
    CHECK_VALUE(count, 5);
}

int main(int argc, char *argv[])
{   
    McoSqlEngine engine;
    engine.open("tpcdb", NULL, MEMORY_DATABASE_SIZE);
    engine.executeStatement("create table Record (id int primary key, value string)");

    printf("Local SQL engine\n");
    run_test(&engine, false);
    query_objects(&engine);

    SqlServer server(&engine, SERVER_PORT);
    server.start();

    RemoteSqlEngine remote_engine;
    remote_engine.open("localhost", SERVER_PORT);

    printf("\nRemote SQL engine\n");
    run_test(&remote_engine, true);
    query_objects(&remote_engine, false);

    remote_engine.close();

    server.stop();
    engine.close();

    return 0;
}
