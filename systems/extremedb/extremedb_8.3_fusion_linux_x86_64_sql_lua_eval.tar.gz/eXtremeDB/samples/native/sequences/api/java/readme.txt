Please find this sample in directory
samples/java/seqapi
