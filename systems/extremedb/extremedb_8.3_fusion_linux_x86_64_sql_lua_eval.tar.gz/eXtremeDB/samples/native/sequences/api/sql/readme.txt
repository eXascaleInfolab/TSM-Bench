Please find these samples in directory
samples/native/sql/xsql/scripts/sequences
