Please find this sample in directory
samples/python/seqapi
