/****************************************************************
 *                                                              *
 * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *  * Copyright (c) 2001-2023 McObject LLC. All Rights Reserved.    *
 *                                                              *
 ****************************************************************/
#include <common.h>
#include <backupdb.h>

#ifdef _WIN32
#define atoll _atoi64
#endif

char sample_descr[] =   "Sample '18-backup-migrate-cipher' demonstrates migration of an existing\n"
                        "DB snapshot to another one with a different cipher key.\n"
                        "Absence of a cipher key command line argument for input or output DB snapshot\n"
                        "means that it is not encrypted.";
const char * db_name =  "backupdb";
const char * usage   =  "memsize (Mb) pagesize (bytes) snapshot_file_in snapshot_file_out [-cipher_in cipher_key_in] [-cipher_out cipher_key_out] [-h]";

/* Stream writer with prototype mco_stream_write */
mco_size_sig_t file_writer( void *stream_handle /* FILE *  */, const void *from, mco_size_t nbytes )
{
    FILE *f = (FILE *)stream_handle;
    mco_size_sig_t nbs;

    nbs = fwrite( from, 1, nbytes, f );
    return nbs;
}

/* Stream reader with prototype mco_stream_read */
mco_size_sig_t file_reader( void *stream_handle /* FILE *  */,  /* OUT */void *to, mco_size_t max_nbytes )
{
    FILE *f = (FILE *)stream_handle;
    mco_size_sig_t nbs;

    nbs = fread( to, 1, max_nbytes, f );
    return nbs;
}

MCO_RET load_snapshot(mco_size_t memory_size, uint2 mem_page_size, char *cipher_key, sample_memory_t *pdev, const char *snapshot_file)
{
    FILE *fbak;
    MCO_RET rc;
    mco_db_params_t    db_params;

    /* Initialize and customize the database parameters */
    mco_db_params_init(&db_params);             /* Initialize the params with default values */

    db_params.mem_page_size = mem_page_size;    /* Set page size for in-memory part */
    db_params.disk_page_size = 0;               /* Set page size for persistent storage */
    db_params.db_max_connections = 1;           /* Set total number of connections to the database */
    db_params.cipher_key_snapshot_tl = cipher_key; /* Set cipher key of database snapshot file */
#ifdef EXTREMEDB_LICENSE_KEY
    db_params.license_key = EXTREMEDB_LICENSE_KEY;
#endif

    fbak = fopen(snapshot_file, "rb");
    if (!fbak)
    {
        printf("Can't open snapshot file %s for reading!", snapshot_file);
        return MCO_E_CORE;
    }

    printf("Load database from a snapshot file..\n");
    rc = sample_load_database_params(fbak, file_reader, db_name, backupdb_get_dictionary(), memory_size, 0, pdev, &db_params);

    fclose(fbak);

    return rc;
}

MCO_RET save_snapshot(mco_db_h con, const char *snapshot_file)
{
    FILE *fbak;
    MCO_RET rc;

    fbak = fopen(snapshot_file, "wb");
    if (!fbak)
    {
        printf("Can't open snapshot file %s for writing!", snapshot_file);
        return MCO_E_CORE;
    }

    printf("Save disk database snapshot file..\n");
    rc = mco_db_save((void *)fbak, file_writer, con);

    fclose(fbak);

    return rc;
}

int parse_cmd_line(int argc, char** argv, char **input_key, char **output_key)
{
    int i = 0;

    while (i < argc && *argv[i] == '-')
    {
        if (strcmp(argv[i], "-cipher_in") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Argument of option -cipher_in was not specified\n");
                return 1;
            }
            *input_key = argv[i];
            i++;
        } else if (strcmp(argv[i], "-cipher_out") == 0) {
            i++;
            if (i >= argc) {
                fprintf(stderr, "Argument of option -cipher_out was not specified\n");
                return 1;
            }
            *output_key = argv[i];
            i++;
        } else {
            fprintf(stderr, "Unknown option %s\n", argv[i]);
            return 1;
        }
    }
    return i < argc ? 1 : 0;
}

int  main(int argc, char** argv)
{
    char *input_file, *output_file;
    char *input_key = 0, *output_key = 0;
    long long memsize;
    int pagesize;
    mco_db_h db = 0;
    sample_memory_t mem_db = { 0 };

    if ((argc != 5 && argc != 7 && argc != 9)
        || (argc > 5 && parse_cmd_line(argc - 5, argv + 5, &input_key, &output_key))
        || (memsize = atoll(argv[1])) <= 0 || (pagesize = atoi(argv[2])) <= 0 || pagesize > 65535
        || strlen(argv[3]) == 0 || strlen(argv[4]) == 0)
    {
        printf("Usage: 18-backup-migrate-cipher %s", usage);
        return (argc == 2 && strcmp(argv[1], "-h") == 0) ? 0 : 1;
    }

    input_file = argv[3];
    output_file = argv[4];

    sample_os_initialize(DEFAULT|DISK);

    /* Start eXtremeDB runtime */
    mco_error_set_handler( &sample_errhandler );
    CHECK(mco_runtime_start());

    sample_header(sample_descr);

    sample_show_runtime_info("The database runtime has the following characteristics:\n" );

    printf("\nProgram options:"
        "\n\tMemory size: %lld Megabytes\n\tMem. page size: %d bytes"
        "\n\tInput DB snapshot file: %s\n\tOutput DB snapshot file: %s"
        "\n\tInput snapshot encryption: %s\n\tOutput snapshot encryption: %s\n\n",
        memsize, pagesize, input_file, output_file,
        input_key ? "yes" : "no", output_key ? "yes" : "no");

    memsize *= 1024*1024;

    printf("Open the database and load the input DB snapshot..\n");
    CHECK(load_snapshot(memsize, pagesize, input_key, &mem_db, input_file));

    printf("Connect to the database..\n");
    CHECK(mco_db_connect(db_name, &db));

    printf("Set the cipher key for the output DB snapshot..\n");
    CHECK(mco_set_cipher_key_snapshot_tl(db, output_key));

    CHECK(save_snapshot(db, output_file));

    printf("Disconnect and close the database..\n");
    CHECK(mco_db_disconnect(db));
    CHECK(sample_close_database(db_name, &mem_db));

    CHECK(mco_runtime_stop());

    sample_pause_end("\n\nPress any key to continue . . . ");

    sample_os_shutdown();
    return 0;
}
