#ifndef _OBJFUNC_H_
    #define _OBJFUNC_H_

    #include "simple.h"

    void doListing(mco_db_h db);
    int createDatabase(mco_db_h db);
    void doGoogle(mco_db_h db);

#endif //_OBJFUNC_H_
