#include <mco.h>
#include <common.h>
#include "structdb.h"

void sequentialScan( mco_db_h db, int iClass );
