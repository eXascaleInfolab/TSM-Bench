#include <mco.h>
#include <common.h>
#include "structdb.h"

void hashSearch( mco_db_h db, int iClass, uint4 nSearches );
