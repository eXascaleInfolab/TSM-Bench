#include <mco.h>
#include <common.h>
#include "structdb.h"

void treeSearch( mco_db_h db, int iClass, uint4 nSearches );
