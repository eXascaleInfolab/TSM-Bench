#include <mco.h>
#include <common.h>
#include "structdb.h"

void searchDelete( mco_db_h db, int iClass, uint4 nObjects, uint4 nDeletesPerTransaction );
