#include <mco.h>
#include <common.h>
#include "structdb.h"

void createObjects( mco_db_h db, int nClass, uint4 nObjects, uint4 nInsertsPerTransaction );
