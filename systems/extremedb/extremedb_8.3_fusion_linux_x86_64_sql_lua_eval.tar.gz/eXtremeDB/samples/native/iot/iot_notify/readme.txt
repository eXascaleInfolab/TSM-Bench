The sample illustrates a three-level topology running three types of components:

1. A single top-tier server (`iot_notify_srv`). It collects Sensor data from all the devices and update Config data. Server accepts connections to port 15000
2. Two mid-tier router (gateway) (`iot_notify_rt`) provides a transparent data flow passing all sensor data to the server. Router accepts connections to port 15001
3. Low tier device (`iot_notify_dev`), connected to the gateway and stores sensor data in its local in-memory database, periodically sending collected data to the connected gateway over the Active Replication Fabric protocol.


To execute the sample, it is necessary to compile this sample, then
start the server application first:

> iot_notify_srv <Enter>

Then run the router application:

> iot_notify_rt [server_host:server_port] <Enter>

And finally run the device app:

> iot_notify_dev [router_host:router_port  [deviceID] ]  <Enter>


