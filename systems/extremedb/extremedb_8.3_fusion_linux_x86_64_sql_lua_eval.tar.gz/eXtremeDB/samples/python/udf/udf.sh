#!/bin/bash

MCO_ROOT=../../..
export LD_LIBRARY_PATH=$MCO_ROOT/target/bin.so
if [ "$(uname)" == "Darwin" ]; then
    DYLD_LIBRARY_PATH=$MCO_ROOT/target/bin.so/:$DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH
fi

$MCO_ROOT/target/bin/xsql -i -f udf.sql

