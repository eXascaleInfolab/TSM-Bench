This is a Sample for using python as User Defined Fuctions in SQL engine.
For more samples on UDF please look at directory samples/xsql/scripts/functions_python
