#!/usr/bin/env bash

if [ "$MCO_ROOT" == "" ]; then
    export MCO_ROOT=../../..
fi

cd `dirname $0`

LD_LIBRARY_PATH=$MCO_ROOT/target/bin.so/:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
if [ "$(uname)" == "Darwin" ]; then
    MCO_LIBRARY_PATH=$MCO_ROOT/target/bin.so
    export MCO_LIBRARY_PATH
    DYLD_LIBRARY_PATH=$MCO_ROOT/target/bin.so/:$DYLD_LIBRARY_PATH
    export DYLD_LIBRARY_PATH
fi

if [[ -z "$PYTHONBIN" ]]
then
	export PYTHONBIN=python
fi

$PYTHONBIN  sequences.py
