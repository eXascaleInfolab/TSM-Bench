To start this sample:

1. Start XSQL in SQL server mode:
    ../../../../target/bin/xsql -p 5001
  It will create empty database testdb and perform commands from user input
2. Run python script wrapped by 
	./rsql.sh
3. Stop xsql when done
	XSQL> exit
