To start sharding sample:

- Start two instances of xsql on localhost:
xsql -size 1024m -p 5000
xsql -size 1024m -p 5001

- start demo:
./Sharding.sh or Sharding.bat
